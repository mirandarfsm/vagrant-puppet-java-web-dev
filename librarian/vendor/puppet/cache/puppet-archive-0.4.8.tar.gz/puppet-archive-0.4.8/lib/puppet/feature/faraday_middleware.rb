require 'puppet/util/feature'

Puppet.features.add(:faraday_middleware, :libs => %(faraday_middleware))
